puppet_agent 
-------

* Puppet module to manage the puppet.conf via Puppet for a node. 
* Supports Puppet Enterprise and Puppet Open Source editions

License
-------

Apache GPL v2

Author
-------

* Brendan Murtagh - [@bmurt](https://github.com/bmurt/)

Support
-------

Please log tickets and issues at https://github.com/bmurt/puppet_agent/issues